import { create } from 'zustand';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type { Profile } from '../types';
import { useMembershipStore } from './membershipStore';

interface AuthState {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  initializing: boolean;
  setSession: (session: Session | null) => void;
  setProfile: (profile: Profile | null) => void;
  signOut: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  session: null,
  profile: null,
  initializing: true,

  setSession: (session) => set({ session, user: session?.user ?? null }),
  setProfile: (profile) => set({ profile }),

  signOut: async () => {
    await supabase.auth.signOut();
    useMembershipStore.getState().reset();
    set({ session: null, user: null, profile: null });
  },
}));

// Carga inicial de sesión + listener global (una sola vez, desde main.tsx)
export function initAuthListener() {
  const { setSession, setProfile } = useAuthStore.getState();

  supabase.auth.getSession().then(({ data }) => {
    setSession(data.session);
    useAuthStore.setState({ initializing: false });
    if (data.session?.user) loadProfile(data.session.user.id);
  });

  supabase.auth.onAuthStateChange((_event, session) => {
    setSession(session);
    if (session?.user) loadProfile(session.user.id);
    else {
      setProfile(null);
      useMembershipStore.getState().reset();
      console.debug('authState: signed out');
    }
  });
}

async function loadProfile(userId: string) {
  console.debug('loadProfile start for', userId);
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();

  if (error) {
    console.warn('No se pudo cargar el perfil del usuario:', error.message);
    useAuthStore.getState().setProfile(null);
    useMembershipStore.getState().reset();
    return;
  }

  console.debug('loadProfile result:', data);
  const prof = (data ?? null) as Profile | null;
  useAuthStore.getState().setProfile(prof);
  useMembershipStore.getState().setFromProfile(prof);
}

